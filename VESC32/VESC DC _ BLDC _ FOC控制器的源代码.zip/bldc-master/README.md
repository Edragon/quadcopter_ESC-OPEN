This is the source code for the VESC DC/BLDC/FOC controller. Read more at  
http://vesc-project.com/
